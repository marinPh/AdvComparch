#run.sh will call the compiled file Simulate with 2 arguments, the first argument is the input file and the second argument is the output file


./build/bin/main $1 $2 $3
