

cd build
make
cd ..
./build/bin/main $1